<nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
     <span class="navbar-text">
          <strong>LabIV - Final</strong>
     </span>
     <ul class="navbar-nav ml-auto">
          <li class="nav-item">
               <a class="nav-link" href="">Agregar Propiedad</a>
          </li>
          <li class="nav-item">
               <a class="nav-link" href="">Listar Propiedades</a>
          </li>   
          <li class="nav-item">
               <a class="nav-link" href="">Cerrar Sesión</a>
          </li>        
     </ul>
</nav>