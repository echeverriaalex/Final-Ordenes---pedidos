<?php
    require_once('nav.php');
?>
<main class="py-5">
     <section id="listado" class="mb-5">
          <div class="container">
               <h2 class="mb-4">Listado de Ordenes</h2>
               <table class="table bg-light-alpha">
                    <thead>                         
                         <th>Código</th>
                         <th>Estado</th>
                         <th>Descripcion</th>
                         <th>Precio</th>
                    </thead>
                    <tbody>                         
                         <tr>                             
                              <td>123</td>
                              <td>Av. Colón 1114</td>
                              <td>2235-222222</td>
                              <td>U$S 300.000</td>
                         </tr>
                         <tr>                              
                              <td>456</td>
                              <td>Güemes 4444</td>
                              <td>451-0000</td>
                              <td>U$S 150.000</td>
                         </tr>
                    </tbody>
               </table>
          </div>
     </section> 
     <sectionclass="mb-5">
          <div class="container">
               <h3 class="mb-4">Eliminar Orden</h3>
               <form class="bg-light-alpha">
                    <div class="row">                         
                         <div class="col-lg-2">
                              <div class="form-group">
                                   <label for="">Código</label>
                                   <input type="text" value="" class="form-control">
                              </div>
                         </div>
                         <div class="col-lg-2">
                              <div class="form-group">
                                   <label for="">&nbsp;</label>
                                   <button type="submit" name="button" class="btn btn-dark ml-auto d-block">Agregar</button>
                              </div>
                         </div>                         
                    </div>                    
               </form>
          </div>
     </section>    
</main>